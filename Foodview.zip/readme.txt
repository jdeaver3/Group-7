To start:

Option 1: Go to Foodview\dist and click the Foodview Executable Jar.
Option 2: If option 1 does not work, open the project in netbeans 8.2 with JavaFX support and run it.