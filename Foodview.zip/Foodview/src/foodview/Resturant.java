/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package foodview;

import java.util.ArrayList;
import java.util.List;

public class Resturant {

    private String name;
    private String description;
    private Integer rating;
    private Integer avgRating;
    private Integer no_of_reviews;
    private List<String> reviews;

    public Resturant() {
        this.no_of_reviews = 0;
        this.avgRating = 0;
        this.rating = 0;
        this.reviews = new ArrayList<>();
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public int getAvgRating() {
        return avgRating;
    }

    public void setAvgRating(Integer avgRating) {
        this.avgRating = avgRating;
    }

    public int getNo_of_reviews() {
        return no_of_reviews;
    }

    public void setNo_of_reviews(Integer no_of_reviews) {
        this.no_of_reviews = no_of_reviews;
    }

    public List<String> getReviews() {
        return reviews;
    }

    public void setReviews(List<String> reviews) {
        this.reviews = reviews;
    }

    public void addReview(String s){
        this.reviews.add(s);
    }

    public void update(Integer rating){
        this.rating += rating;
        this.no_of_reviews++;
        this.avgRating = rating/no_of_reviews;
    }



}
