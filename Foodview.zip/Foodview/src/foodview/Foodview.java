/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package foodview;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.control.SelectionMode;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import java.util.ArrayList;
import java.util.List;

public class Foodview extends Application {

    public List<Resturant> resturantReviews = new ArrayList<Resturant>();
    int index = 0;

    @Override
    public void start(Stage stage) {

        Text mainHeading = new Text("Select a resturant or create one to review!");

        TextField searchBar = new TextField();
        Button searchButton = new Button("Search/Review");
        Button createButton = new Button("Create");
        Button topTen = new Button("View Top 10 Resturants");
        ListView<String> listResNames = new ListView<>();
        listResNames.getSelectionModel().setSelectionMode(SelectionMode.SINGLE);
        createButton.setPrefWidth(450);
        GridPane newGridPane = new GridPane();

        newGridPane.setMinSize(500, 600);

        newGridPane.setPadding(new Insets(12, 13, 12, 13));

        newGridPane.setVgap(17);
        newGridPane.setHgap(15);

        newGridPane.add(mainHeading, 1, 0);

        newGridPane.add(searchBar, 1, 1);
        newGridPane.add(searchButton, 2, 1);
        newGridPane.add(createButton, 1, 2);
        newGridPane.add(listResNames, 1, 3);
        newGridPane.add(topTen,1,4);

        mainHeading.setStyle("-fx-font: normal bold 16px 'serif' ");
        newGridPane.setStyle("-fx-background-color:  rgb(240,255,240);");

        Scene scene = new Scene(newGridPane);
        stage.setTitle("Foodview");
        stage.setScene(scene);

        createButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {

                Text mainHeading = new Text("Enter Resturant Details");
                Text textName = new Text("Enter Name:");
                Text textDes = new Text("Enter Description:");
                TextField name = new TextField();
                Button submit = new Button("Submit");
                Button cancel = new Button("Cancel");
                TextField description = new TextField();
                description.setPrefWidth(400);
                description.setPrefHeight(200);
                Stage reviewResturant = new Stage();
                GridPane gridPane = new GridPane();
                gridPane.setMinSize(500, 600);
                gridPane.setPadding(new Insets(12, 13, 12, 13));
                gridPane.setVgap(17);
                gridPane.setHgap(15);
                Scene scene2 = new Scene(gridPane);
                reviewResturant.setScene(scene2);
                mainHeading.setStyle("-fx-font: normal bold 16px 'serif' ");
                gridPane.setStyle("-fx-background-color:  rgb(240,255,240);");
                reviewResturant.setTitle("Resturant Review");
                gridPane.add(mainHeading, 1, 0);
                gridPane.add(textName, 1, 1);
                gridPane.add(name, 1, 2);
                gridPane.add(textDes, 1, 3);
                gridPane.add(description, 1, 4);
                gridPane.add(submit, 1, 5);
                gridPane.add(cancel, 1, 6);
                cancel.setOnAction(new EventHandler<ActionEvent>() {
                    @Override
                    public void handle(ActionEvent event) {
                        reviewResturant.hide();
                        stage.show();
                    }
                });
                submit.setOnAction(new EventHandler<ActionEvent>() {
                    @Override
                    public void handle(ActionEvent event) {
                        Resturant res = new Resturant();
                        res.setName(name.getText());
                        res.setDescription(description.getText());
                        resturantReviews.add(res);
                        listResNames.getItems().add(res.getName());
                        reviewResturant.hide();
                        stage.show();
                    }
                });
                stage.hide();
                reviewResturant.show();
            }
        });

        searchButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                String resName = searchBar.getText();
                if(resName == null || resName.equals(""))
                    resName = listResNames.getSelectionModel().getSelectedItem();
                for(int i = 0; i < resturantReviews.size(); i++) {
                    if (resName.equals(resturantReviews.get(i).getName())) {
                        index = i;
                        break;
                    }
                }
                Stage review = new Stage();
                GridPane gridPaneReview = new GridPane();
                Scene scene3 = new Scene(gridPaneReview);
                review.setScene(scene3);

                Button doneButton = new Button("Done");
                TextField rev = new TextField();
                ListView<Integer> ratings = new ListView<>();
                ratings.getItems().addAll(1,2,3,4,5);
                listResNames.getSelectionModel().setSelectionMode(SelectionMode.SINGLE);
                gridPaneReview.setPadding(new Insets(12, 13, 12, 13));
                gridPaneReview.setVgap(17);
                gridPaneReview.setHgap(15);

                Text heading = new Text("Enter Review for " + resturantReviews.get(index).getName());
                heading.setStyle("-fx-font: normal bold 16px 'serif' ");
                gridPaneReview.add(heading, 1, 0);
                gridPaneReview.add(rev, 1, 1);
                gridPaneReview.add(ratings,1,2);
                gridPaneReview.add(doneButton,1,3);
                review.show();

                doneButton.setOnAction(new EventHandler<ActionEvent>() {
                    @Override
                    public void handle(ActionEvent event) {
                        resturantReviews.get(index).addReview(rev.getText());
                        resturantReviews.get(index).update(ratings.getSelectionModel().getSelectedItem());
                        review.hide();
                    }
                });
            }
        });
        topTen.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                Stage topTenStage = new Stage();
                Button back = new Button("Back");
                GridPane topTenGridPane = new GridPane();
                Scene scene3 = new Scene(topTenGridPane);
                topTenStage.setScene(scene3);

                topTenGridPane.setPadding(new Insets(12, 13, 12, 13));
                topTenGridPane.setVgap(17);
                topTenGridPane.setHgap(15);

                Text heading = new Text("Top Ten Resturants");
                heading.setStyle("-fx-font: normal bold 16px 'serif' ");

                ListView<String> topTenResturants = new ListView<>();
                for(int i = 0; i < resturantReviews.size(); i++){
                    topTenResturants.getItems().add(resturantReviews.get(i).getName());
                }

                topTenGridPane.add(heading , 1 , 0);
                topTenGridPane.add(topTenResturants,1,1);
                topTenGridPane.add(back,1,2);
                topTenStage.show();
                back.setOnAction(new EventHandler<ActionEvent>() {
                    @Override
                    public void handle(ActionEvent event) {
                        topTenStage.hide();
                    }
                });
            }
        });
        stage.show();
    }

    public static void main(String args[]) {
        launch(args);
    }
}
